Shipment Tracker by Iceburg333
Download updates and see your stats at:
http://www.iceburgmodding.com/StardewShipmentTracker/index.html